The Double Fine Action Forum Adventure Game
===========================================

This is an attempt at making a comedic point and click graphic adventure game featuring people from the Double Fine Action Forums.  Those who are participating in this are:

Jenni, AnAnemoneInAnonymity, Noname215, Darth Marsden, Feddlefew, Fhqwhgads, Klatuu, St_Eddie, and Remolay

Contributions so far:
art: Jenni
avatar art: Klatuu

If you wish to join in, you can still participate by asking to be a part of this at the Double Fine forums and I'll draw a likeness of you for the game (you'll have the final say on how your likeness appears) or you can draw your own avatar if you like.  

http://www.doublefine.com/forums/viewthread/14577

You can also contribute by submitting code, art, or music through the dfafadventure branch on github.

https://github.com/JenniBee/dfafadventure

Any and all help is appreciated! :)

This project uses the Wintermute engine by dead:code.

http://dead-code.org/home/

It is being optimized for use with the Wintermute engine in ScummVM, which was developed by somaen, t0by, and the ScummVM team.

http://www.scummvm.org/
